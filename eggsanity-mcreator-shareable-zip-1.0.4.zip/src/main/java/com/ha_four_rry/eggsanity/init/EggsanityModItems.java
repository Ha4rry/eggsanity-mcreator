
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.ha_four_rry.eggsanity.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import com.ha_four_rry.eggsanity.item.MagicEggSwordItem;
import com.ha_four_rry.eggsanity.item.MagicEggPickaxeItem;
import com.ha_four_rry.eggsanity.item.MagicEggItem;
import com.ha_four_rry.eggsanity.item.MagicEggAxeItem;
import com.ha_four_rry.eggsanity.item.GodItem;
import com.ha_four_rry.eggsanity.item.EyeOfDaisyItem;
import com.ha_four_rry.eggsanity.item.DaisysPawItem;
import com.ha_four_rry.eggsanity.item.CookedEggItem;
import com.ha_four_rry.eggsanity.item.BurberItem;
import com.ha_four_rry.eggsanity.EggsanityMod;

public class EggsanityModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, EggsanityMod.MODID);
	public static final RegistryObject<Item> COOKED_EGG = REGISTRY.register("cooked_egg", () -> new CookedEggItem());
	public static final RegistryObject<Item> MAGIC_EGG = REGISTRY.register("magic_egg", () -> new MagicEggItem());
	public static final RegistryObject<Item> EGG_MAGIC_TABLE = block(EggsanityModBlocks.EGG_MAGIC_TABLE);
	public static final RegistryObject<Item> MAGIC_EGG_SWORD = REGISTRY.register("magic_egg_sword", () -> new MagicEggSwordItem());
	public static final RegistryObject<Item> MAGIC_EGG_PICKAXE = REGISTRY.register("magic_egg_pickaxe", () -> new MagicEggPickaxeItem());
	public static final RegistryObject<Item> MAGIC_EGG_BLOCK = block(EggsanityModBlocks.MAGIC_EGG_BLOCK);
	public static final RegistryObject<Item> MAGIC_EGG_AXE = REGISTRY.register("magic_egg_axe", () -> new MagicEggAxeItem());
	public static final RegistryObject<Item> EYE_OF_DAISY = REGISTRY.register("eye_of_daisy", () -> new EyeOfDaisyItem());
	public static final RegistryObject<Item> DAISYS_PAW = REGISTRY.register("daisys_paw", () -> new DaisysPawItem());
	public static final RegistryObject<Item> BURBER_HELMET = REGISTRY.register("burber_helmet", () -> new BurberItem.Helmet());
	public static final RegistryObject<Item> BURBER_CHESTPLATE = REGISTRY.register("burber_chestplate", () -> new BurberItem.Chestplate());
	public static final RegistryObject<Item> BURBER_LEGGINGS = REGISTRY.register("burber_leggings", () -> new BurberItem.Leggings());
	public static final RegistryObject<Item> BURBER_BOOTS = REGISTRY.register("burber_boots", () -> new BurberItem.Boots());
	public static final RegistryObject<Item> GOD_HELMET = REGISTRY.register("god_helmet", () -> new GodItem.Helmet());
	public static final RegistryObject<Item> GOD_CHESTPLATE = REGISTRY.register("god_chestplate", () -> new GodItem.Chestplate());
	public static final RegistryObject<Item> GOD_LEGGINGS = REGISTRY.register("god_leggings", () -> new GodItem.Leggings());
	public static final RegistryObject<Item> GOD_BOOTS = REGISTRY.register("god_boots", () -> new GodItem.Boots());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
