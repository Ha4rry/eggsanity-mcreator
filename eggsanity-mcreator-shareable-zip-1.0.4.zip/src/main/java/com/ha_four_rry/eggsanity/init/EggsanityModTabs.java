
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.ha_four_rry.eggsanity.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import com.ha_four_rry.eggsanity.EggsanityMod;

public class EggsanityModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, EggsanityMod.MODID);
	public static final RegistryObject<CreativeModeTab> EGGS_ARE_NOW_INSANE_CREATIVE_TAB = REGISTRY.register("eggs_are_now_insane_creative_tab",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.eggsanity.eggs_are_now_insane_creative_tab")).icon(() -> new ItemStack(EggsanityModItems.MAGIC_EGG.get())).displayItems((parameters, tabData) -> {
				tabData.accept(EggsanityModItems.COOKED_EGG.get());
				tabData.accept(EggsanityModItems.MAGIC_EGG.get());
				tabData.accept(EggsanityModBlocks.EGG_MAGIC_TABLE.get().asItem());
				tabData.accept(EggsanityModItems.MAGIC_EGG_SWORD.get());
				tabData.accept(EggsanityModItems.MAGIC_EGG_PICKAXE.get());
				tabData.accept(EggsanityModBlocks.MAGIC_EGG_BLOCK.get().asItem());
				tabData.accept(EggsanityModItems.MAGIC_EGG_AXE.get());
				tabData.accept(EggsanityModItems.EYE_OF_DAISY.get());
				tabData.accept(EggsanityModItems.DAISYS_PAW.get());
				tabData.accept(EggsanityModItems.BURBER_HELMET.get());
				tabData.accept(EggsanityModItems.BURBER_CHESTPLATE.get());
				tabData.accept(EggsanityModItems.BURBER_LEGGINGS.get());
				tabData.accept(EggsanityModItems.BURBER_BOOTS.get());
				tabData.accept(EggsanityModItems.GOD_HELMET.get());
				tabData.accept(EggsanityModItems.GOD_CHESTPLATE.get());
				tabData.accept(EggsanityModItems.GOD_LEGGINGS.get());
				tabData.accept(EggsanityModItems.GOD_BOOTS.get());
			}).build());
}
