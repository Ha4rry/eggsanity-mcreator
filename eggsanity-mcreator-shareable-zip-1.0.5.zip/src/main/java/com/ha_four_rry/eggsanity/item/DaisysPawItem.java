
package com.ha_four_rry.eggsanity.item;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.network.chat.Component;

import java.util.List;

import com.ha_four_rry.eggsanity.procedures.EntityHitByDaisysPawProcedure;
import com.ha_four_rry.eggsanity.init.EggsanityModItems;

public class DaisysPawItem extends SwordItem {
	public DaisysPawItem() {
		super(new Tier() {
			public int getUses() {
				return 128000;
			}

			public float getSpeed() {
				return 255f;
			}

			public float getAttackDamageBonus() {
				return 127996f;
			}

			public int getLevel() {
				return 4;
			}

			public int getEnchantmentValue() {
				return 500;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(EggsanityModItems.EYE_OF_DAISY.get()));
			}
		}, 3, -2.4f, new Item.Properties().fireResistant());
	}

	@Override
	public boolean hurtEnemy(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
		boolean retval = super.hurtEnemy(itemstack, entity, sourceentity);
		EntityHitByDaisysPawProcedure.execute(entity.level(), entity.getX(), entity.getY(), entity.getZ(), entity);
		return retval;
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Level level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, level, list, flag);
		list.add(Component.translatable("item.eggsanity.daisys_paw.description_0"));
	}

	@Override
	@OnlyIn(Dist.CLIENT)
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}
