package com.ha_four_rry.eggsanity.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.projectile.ThrownEgg;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.server.level.ServerLevel;

public class EntityHitByMagicEggSwordProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(MobEffects.HUNGER, 200, 3));
		for (int index0 = 0; index0 < 15; index0++) {
			if (world instanceof ServerLevel projectileLevel) {
				Projectile _entityToSpawn = new Object() {
					public Projectile getProjectile(Level level, Entity shooter) {
						Projectile entityToSpawn = new ThrownEgg(EntityType.EGG, level);
						entityToSpawn.setOwner(shooter);
						return entityToSpawn;
					}
				}.getProjectile(projectileLevel, entity);
				_entityToSpawn.setPos((entity.getX()), (entity.getY()), (entity.getZ()));
				_entityToSpawn.shoot(Math.random(), Math.random(), Math.random(), 1, 0);
				projectileLevel.addFreshEntity(_entityToSpawn);
			}
		}
	}
}
