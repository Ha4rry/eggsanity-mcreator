
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.ha_four_rry.eggsanity.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import com.ha_four_rry.eggsanity.block.MagicEggBlockBlock;
import com.ha_four_rry.eggsanity.block.EggMagicTableBlock;
import com.ha_four_rry.eggsanity.EggsanityMod;

public class EggsanityModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, EggsanityMod.MODID);
	public static final RegistryObject<Block> EGG_MAGIC_TABLE = REGISTRY.register("egg_magic_table", () -> new EggMagicTableBlock());
	public static final RegistryObject<Block> MAGIC_EGG_BLOCK = REGISTRY.register("magic_egg_block", () -> new MagicEggBlockBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
