
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package com.ha_four_rry.eggsanity.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

import com.ha_four_rry.eggsanity.world.inventory.EggMagicTableGUIMenu;
import com.ha_four_rry.eggsanity.EggsanityMod;

public class EggsanityModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, EggsanityMod.MODID);
	public static final RegistryObject<MenuType<EggMagicTableGUIMenu>> EGG_MAGIC_TABLE_GUI = REGISTRY.register("egg_magic_table_gui", () -> IForgeMenuType.create(EggMagicTableGUIMenu::new));
}
